import { motion } from 'framer-motion'

const testimonials = [
  { name: "Jamie R.", text: "SLW transformed our living room — professional, fast, and the finish is flawless!" },
  { name: "Carlos M.", text: "Great communication and attention to detail. Highly recommend for exterior work." },
  { name: "Aisha P.", text: "Friendly crew and beautiful custom finish on our feature wall." }
];

const gallery = [
  "https://source.unsplash.com/collection/483251/800x600",
  "https://source.unsplash.com/collection/190727/800x600",
  "https://source.unsplash.com/collection/1111575/800x600"
];

export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <svg className="w-full h-full" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <radialGradient id="g" cx="50%" cy="30%">
                <stop offset="0%" stopColor="#E6F7FF" />
                <stop offset="100%" stopColor="#FFFFFF" />
              </radialGradient>
            </defs>
            <rect width="100%" height="100%" fill="url(#g)" />
            <circle cx="50" cy="60" r="36" fill="#63b3ed" opacity=".12" />
            <circle cx="150" cy="20" r="18" fill="#60a5fa" opacity=".10" />
            <circle cx="720" cy="120" r="46" fill="#7dd3fc" opacity=".08" />
            <ellipse cx="640" cy="40" rx="80" ry="30" fill="#93c5fd" opacity=".06" />
          </svg>
        </div>

        <div className="max-w-6xl mx-auto py-20 px-6 text-center">
          <img src="/logo.png" alt="SLW Painting logo" className="mx-auto w-36 h-36 object-contain mb-4" />
          <h1 className="text-5xl font-extrabold mb-3">SLW Painting LLC</h1>
          <p className="text-xl text-gray-700 mb-6">Professional Residential & Commercial Painting with a personal touch</p>
          <div className="flex justify-center gap-4">
            <a href="tel:+14804758721" className="inline-flex items-center px-6 py-3 rounded-lg text-base font-medium text-blue-700 bg-white shadow">Call: (480) 475-8721</a>
            <a href="mailto:slwpaintingllc@gmail.com" className="inline-flex items-center px-6 py-3 rounded-lg text-base font-medium bg-blue-600 text-white hover:bg-blue-700">Email Us</a>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 px-6 md:px-20">
        <h2 className="text-3xl font-bold text-center mb-8">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { title: "Interior Painting", desc: "Freshen up your living spaces with flawless finishes." },
            { title: "Exterior Painting", desc: "Boost curb appeal with durable, weather-resistant coatings." },
            { title: "Custom Finishes", desc: "Unique textures and designs tailored to your style." }
          ].map((service, i) => (
            <motion.div key={service.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i*0.12 }}>
              <div className="shadow rounded-2xl h-full p-6 text-center">
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Gallery */}
      <section className="bg-gray-50 py-16 px-6 md:px-20">
        <h2 className="text-3xl font-bold text-center mb-8">Portfolio</h2>
        <p className="text-center text-gray-600 mb-8">A few examples of projects we've completed (replace these with your own photos)</p>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {gallery.map((src, i) => (
            <div key={i} className="rounded-lg overflow-hidden shadow">
              <img src={src} alt={`Project ${i+1}`} className="w-full h-48 object-cover" />
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-6 md:px-20">
        <h2 className="text-3xl font-bold text-center mb-8">What Clients Say</h2>
        <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div key={i} className="rounded-xl border p-6 shadow">
              <p className="text-gray-700 mb-4">"{t.text}"</p>
              <p className="font-semibold">— {t.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-12 px-6 md:px-20 text-center">
        <h3 className="text-2xl font-bold mb-3">Ready to transform your space?</h3>
        <p className="mb-6">Email us at <a href="mailto:slwpaintingllc@gmail.com" className="underline">slwpaintingllc@gmail.com</a> or call (480) 475-8721 for a free estimate.</p>
      </section>

      <footer className="bg-gray-900 text-white text-center py-6">
        <p>© {new Date().getFullYear()} SLW Painting LLC. All rights reserved.</p>
      </footer>
    </div>
  )
}
